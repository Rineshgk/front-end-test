declare module '*.less';
