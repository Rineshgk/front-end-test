export const ratings = {
    '5+': {count: 5, plus: true, aria: '5 plus star'},
    '5': {count: 5, plus: false, aria: '5 star'},
    '4+': {count: 4, plus: true, aria: '4 plus star'},
    '4': {count: 4, plus: false, aria: '4 star'},
    '3+': {count: 3, plus: true, aria: '3 plus star'},
    '3': {count: 3, plus: false, aria: '3 star'},
    '2+': {count: 2, plus: true, aria: '2 plus star'},
    '2': {count: 2, plus: false, aria: '2 star'},
    '1+': {count: 1, plus: true, aria: '1 plus star'},
    '1': {count: 1, plus: false, aria: '1 star'}
}