export const lang = {
    'rating': 'Rating',
    'pricePerPerson': 'Price (PP)',
    'facility': 'Facility'
}